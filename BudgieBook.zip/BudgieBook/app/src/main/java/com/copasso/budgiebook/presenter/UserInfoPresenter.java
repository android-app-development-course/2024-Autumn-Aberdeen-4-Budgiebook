package com.copasso.budgiebook.presenter;


import com.copasso.budgiebook.base.RxPresenter;
import com.copasso.budgiebook.model.bean.remote.MyUser;
import com.copasso.budgiebook.presenter.contract.UserInfoContract;


public class UserInfoPresenter extends RxPresenter<UserInfoContract.View>
        implements UserInfoContract.Presenter {

    private String TAG = "UserInfoPresenter";

    @Override
    public void updateUser(MyUser user) {

    }
}
