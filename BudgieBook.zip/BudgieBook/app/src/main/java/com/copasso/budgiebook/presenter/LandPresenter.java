package com.copasso.budgiebook.presenter;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.copasso.budgiebook.base.RxPresenter;
import com.copasso.budgiebook.db.MyDBHelper;
import com.copasso.budgiebook.model.bean.remote.MyUser;
import com.copasso.budgiebook.presenter.contract.LandContract;


public class LandPresenter extends RxPresenter<LandContract.View> implements LandContract.Presenter {

    private String TAG = "LandPresenter";
    private MyDBHelper dbHelper;

    public LandPresenter(Context context) {
        dbHelper = new MyDBHelper(context, "UserStore.db", null, 1);
    }

    @Override
    public void login(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String sql = "select * from userData where name=? and password=?";
        Cursor cursor = db.rawQuery(sql, new String[]{username, password});
        if (cursor.moveToFirst()) {
            MyUser myUser = new MyUser();
            myUser.setUsername(username);
            myUser.setPassword(password);
            if (cursor.getCount() > 0) {
                mView.landSuccess(myUser);
                cursor.close();
                return;
            }
        }
        Throwable throwable = new Throwable("登录失败，账号或者密码错误");
        mView.onFailure(throwable);

    }

    @Override
    public void signup(String username, String password) {
        MyUser myUser = new MyUser();
        myUser.setUsername(username);
        myUser.setPassword(password);
        if (CheckIsDataAlreadyInDBorNot(username)) {
            Throwable throwable = new Throwable("该用户名已被注册，注册失败");
            mView.onFailure(throwable);
        } else {
            register(username, password);
            mView.landSuccess(myUser);
        }
//        myUser.signUp(new SaveListener<MyUser>() {
//            @Override
//            public void done(MyUser myUser, BmobException e) {
//                if(e==null) {
//                    mView.landSuccess(myUser);
//                }
//                else {
//                    mView.onFailure(e);
//                }
//            }
//        });
    }

    //向数据库插入数据
    public boolean register(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        /*String sql = "insert into userData(name,password) value(?,?)";
        Object obj[]={username,password};
        db.execSQL(sql,obj);*/
        ContentValues values = new ContentValues();
        values.put("name", username);
        values.put("password", password);
        db.insert("userData", null, values);
        db.close();
        //db.execSQL("insert into userData (name,password) values (?,?)",new String[]{username,password});
        return true;
    }

    //检验用户名是否已存在
    public boolean CheckIsDataAlreadyInDBorNot(String value) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String Query = "Select * from userData where name =?";
        Cursor cursor = db.rawQuery(Query, new String[]{value});
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;
    }
}
