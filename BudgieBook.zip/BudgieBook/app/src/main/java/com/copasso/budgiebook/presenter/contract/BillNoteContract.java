package com.copasso.budgiebook.presenter.contract;

import com.copasso.budgiebook.base.BaseContract;
import com.copasso.budgiebook.model.bean.local.BSort;
import com.copasso.budgiebook.model.bean.local.NoteBean;

import java.util.List;


public interface BillNoteContract extends BaseContract {

    interface View extends BaseView {

        void loadDataSuccess(NoteBean bean);

    }

    interface Presenter extends BasePresenter<View> {
        /**
         * 获取信息
         */
        void getBillNote();

        void updateBBsorts(List<BSort> items);

        void addBSort(BSort bSort);

        void deleteBSortByID(Long id);
    }
}
