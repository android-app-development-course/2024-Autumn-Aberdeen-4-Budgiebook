package com.copasso.budgiebook.ui.activity;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.copasso.budgiebook.R;
import com.copasso.budgiebook.base.BaseMVPActivity;
import com.copasso.budgiebook.model.bean.remote.MyUser;
import com.copasso.budgiebook.presenter.LandPresenter;
import com.copasso.budgiebook.presenter.contract.LandContract;
import com.copasso.budgiebook.utils.ProgressUtils;
import com.copasso.budgiebook.utils.SharedPUtils;
import com.copasso.budgiebook.utils.SnackbarUtils;
import com.copasso.budgiebook.widget.OwlView;

/**
 * 用户登录、注册activity
 */
public class LandActivity extends BaseMVPActivity<LandContract.Presenter>
        implements LandContract.View, View.OnFocusChangeListener, View.OnClickListener {

    private OwlView mOwlView;
    private EditText emailET;
    private EditText usernameET;
    private EditText passwordET;
    private EditText rpasswordET;
    private TextView signTV;
    private TextView forgetTV;
    private Button loginBtn;

    //是否是登录操作
    private boolean isLogin = true;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_user_land;
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        mOwlView = findViewById(R.id.land_owl_view);
        emailET = findViewById(R.id.login_et_email);
        usernameET = findViewById(R.id.login_et_username);
        passwordET = findViewById(R.id.login_et_password);
        rpasswordET = findViewById(R.id.login_et_rpassword);
        signTV = findViewById(R.id.login_tv_sign);
        forgetTV = findViewById(R.id.login_tv_forget);
        loginBtn = findViewById(R.id.login_btn_login);
    }

    @Override
    protected void initClick() {
        super.initClick();
        passwordET.setOnFocusChangeListener(this);
        rpasswordET.setOnFocusChangeListener(this);
        signTV.setOnClickListener(this);
        forgetTV.setOnClickListener(this);
        loginBtn.setOnClickListener(this);
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus) {
            mOwlView.open();
        } else {
            mOwlView.close();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login_btn_login:  //button
                if (isLogin) {
                    login();  //登录
                } else {
                    sign();  //注册
                }
                break;
            case R.id.login_tv_sign:  //sign
                if (isLogin) {
                    //置换注册界面
                    signTV.setText("登录");
                    loginBtn.setText("注册");
                    rpasswordET.setVisibility(View.VISIBLE);
                    emailET.setVisibility(View.GONE);
                } else {
                    //置换登录界面
                    signTV.setText("注册");
                    loginBtn.setText("登录");
                    rpasswordET.setVisibility(View.GONE);
                    emailET.setVisibility(View.GONE);
                }
                isLogin = !isLogin;
                break;
            case R.id.login_tv_forget:  //忘记密码
                break;
            default:
                break;
        }
    }

    /**
     * 执行登录动作
     */
    public void login() {
        String username = usernameET.getText().toString();
        String password = passwordET.getText().toString();
        if (username.length() == 0 || password.length() == 0) {
            SnackbarUtils.show(mContext, "用户名或密码不能为空");
            return;
        }

        ProgressUtils.show(this, "正在登录...");

        mPresenter.login(username, password);
    }

    /**
     * 执行注册动作
     */
    public void sign() {
        // String email = emailET.getText().toString();
        String username = usernameET.getText().toString();
        String password = passwordET.getText().toString();
        String rpassword = rpasswordET.getText().toString();
        if (username.length() == 0 || password.length() == 0 || rpassword.length() == 0) {
            SnackbarUtils.show(mContext, "请填写必要信息");
            return;
        }
//        if (!StringUtils.checkEmail(email)) {
//            SnackbarUtils.show(mContext, "请输入正确的邮箱格式");
//            return;
//        }
        if (!password.equals(rpassword)) {
            SnackbarUtils.show(mContext, "两次密码不一致");
            return;
        }

        ProgressUtils.show(this, "正在注册...");

        mPresenter.signup(username, password);

    }

    /***********************************************************************/

    @Override
    protected LandContract.Presenter bindPresenter() {
        return new LandPresenter(LandActivity.this);
    }

    @Override
    public void landSuccess(MyUser user) {
        ProgressUtils.dismiss();
        if (isLogin) {
            setResult(RESULT_OK, new Intent());
            SharedPUtils.writePhone(this, user.getUsername());
            Intent intent = new Intent();
            intent.setClass(LandActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            SnackbarUtils.show(mContext, "注册成功");
            //置换登录界面
            signTV.setText("注册");
            loginBtn.setText("登录");
            rpasswordET.setVisibility(View.GONE);
            emailET.setVisibility(View.GONE);

            isLogin = !isLogin;
        }
        Log.i(TAG, user.toString());
    }

    @Override
    public void onSuccess() {
    }

    @Override
    public void onFailure(Throwable e) {
        ProgressUtils.dismiss();
        SnackbarUtils.show(mContext, e.getMessage());
        Log.e(TAG, e.getMessage());
    }
}
